package StepDefinitions;

import PageObject.GroupChatPage;
import PageObject.HomePage;
import PageObject.KBpage;
import PageObject.TestingTeamPage;
import Runner.Hooks;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.cucumber.java.BeforeStep;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class KBsteps {
    public static AndroidDriver<AndroidElement> driver;

    KBpage kBpage;
    HomePage homePage;
    TestingTeamPage testingTeamPage;

    public KBsteps() {
        super();
        this.driver = Hooks.driver;
    }

    @BeforeStep
    public void beforeSetup() {
        kBpage = new KBpage (driver);
        homePage = new HomePage(driver);
        testingTeamPage = new TestingTeamPage(driver);

    }
    @Given("User already open Staging Cicle App and Click Testing team")
    public void userAlreadyOpenStagingCicleAppAndClickTestingTeam() {
        homePage.ClickTestingTeam();
    }

    @When("User click Kanban Board")
    public void userClickKanbanBoard() {
        testingTeamPage.ClickKanbanBoard();
    }

    ////////////// (Positive) Add Board List //////////////

    @And("User click Add button")
    public void userClickAddButton() {
        kBpage.ClickAddBoardListButton();
    }

    @And("User input board name with text {string} in board list")
    public void userInputBoardNameWithTextInBoardList(String str) {
        kBpage.InputBoardListNameField("Test board");
    }

    @And("User click submit button")
    public void userClickSubmitButton() {
        kBpage.ClickBoardListSubmitButton();
    }

    @Then("User can see Board list is successfully created")
    public void userCanSeeBoardListIsSuccessfullyCreated() throws InterruptedException {
        Thread.sleep(1000);
    }

    ////////////// (Positive) Add Card //////////////

    @And("User click add new card button in created board")
    public void userClickAddNewCardButtonInCreatedBoard() {
        kBpage.ClickAddNewCardButton();
    }

    @And("User input card name {string} in card name field")
    public void userInputCardNameInCardNameField(String str) {
        kBpage.InputCardNameField("Testing card");
    }

    @And("User click checklist button")
    public void userClickChecklistButton() {
        kBpage.ClickSaveCardButton();
    }

    @Then("User can see Card is successfully created")
    public void userCanSeeCardIsSuccessfullyCreated() throws InterruptedException {
        Thread.sleep(1500);
    }

    ////////////// (Positive) Add Comment in Card //////////////

    @And("User select card that already created")
    public void userSelectCardThatAlreadyCreated() {
        kBpage.ClickTestingCardButton1();
    }

    @And("User input {string} in add new comment field")
    public void userInputInAddNewCommentField(String str) {
        kBpage.ClickNewCommentCardField();
        kBpage.ClickInputCommentCardField("Testing");
    }

    @And("User click submit comment button")
    public void userClickSubmitCommentButton() {
        kBpage.ClickSubmitCommentCardButton();
    }

    @Then("User can see comment is successfully added")
    public void userCanSeeCommentIsSuccessfullyAdded() {
    }

    ////////////// (Positive) Add attach file in Card //////////////

    @And("User click card that already created")
    public void userClickCardThatAlreadyCreated() throws InterruptedException {
        Thread.sleep(1000);
        kBpage.ClickTestingCardButton();
    }

    @And("User click attach file in card")
    public void userClickAttachFileInCard() {
        kBpage.ClickAttachFileCard();
    }

    @And("User select and click the file")
    public void userSelectAndClickTheFile() {
        kBpage.ClickSelectFileAttachCard();
    }

    @And("User click select button")
    public void userClickSelectButton() {
        kBpage.ClickSelectFileButton();
    }

    @Then("User can see pop up successfully attach file")
    public void userCanSeePopUpSuccessfullyAttachFile() throws InterruptedException {
        Thread.sleep(1000);
        kBpage.MessageUploadAttachSuccess();
    }

    ////////////// (Positive) Archive board //////////////

    @And("User click Menu button in selected board")
    public void userClickMenuButtonInSelectedBoard() {
        kBpage.ClickMenuBoardButton();
    }

    @And("User click Archive this list button")
    public void userClickArchiveThisListButton() {
        kBpage.ClickArchiveBoardList();
    }

    @Then("User can see message successfully archive")
    public void userCanSeeMessageSuccessfullyArchive() throws InterruptedException {
        Thread.sleep(1000);
        kBpage.NotifMessageArchiveBoardList();
    }

    ////////////// (Negative) cannot create Board List with blank data //////////////

    @Then("User can see Board List not created")
    public void userCanSeeBoardListNotCreated() {
        kBpage.VerifyTitleAddBoardList();
    }

    ////////////// (Negative) cannot create Card with blank data //////////////

    @Then("User can see Card is not created")
    public void userCanSeeCardIsNotCreated() {
        kBpage.VerifyAddNewCardButton();
    }

    ////////////// (Negative) cannot Comment in Card with blank data //////////////

    @And("user click comment field in Card")
    public void userClickCommentFieldInCard() {
        kBpage.ClickNewCommentCardField();
    }

    ////////////// (Positive) Archive board //////////////

    @And("User click button show menu")
    public void userClickButtonShowMenu() {
        kBpage.ClickShowMenuCIButton();
    }

    @And("User select and click set card to private")
    public void userSelectAndClickSetCardToPrivate() {
        kBpage.ClickSetCardPrivateCI();
    }

    @Then("User can see pop up Update card is success")
    public void userCanSeePopUpUpdateCardIsSuccess() {
        kBpage.VerifyMessageUpdateCard();
    }
}
