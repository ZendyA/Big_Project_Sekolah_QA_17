package StepDefinitions;

import PageObject.GroupChatPage;
import PageObject.HomePage;
import PageObject.TestingTeamPage;
import Runner.Hooks;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.cucumber.java.BeforeStep;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class GroupChatSteps {
    public static AndroidDriver<AndroidElement> driver;

    GroupChatPage groupChatPage;
    HomePage homePage;
    TestingTeamPage testingTeamPage;

    public GroupChatSteps() {
        super();
        this.driver = Hooks.driver;
    }

    @BeforeStep
    public void beforeSetup() {
        groupChatPage = new GroupChatPage(driver);
        homePage = new HomePage(driver);
        testingTeamPage = new TestingTeamPage(driver);

    }
    @Given("^user already at Staging Cicle app and click testing team$")
    public void userAlreadyAtStagingCicleAppAndClickTestingTeam() {
        homePage.ClickTestingTeam();
    }

    @When("^user click group chat$")
    public void userClickGroupChat() {
        testingTeamPage.ClickGroupChat();
    }


    ////////////// (Positive) Input text in Group Chat //////////////
    @And("user input text {string} and send it")
    public void userInputTextHelloAndSendIt(String keyword) throws InterruptedException {
        groupChatPage.clickMessageField();
        Thread.sleep(1000);
        groupChatPage.inputMessageField("Test");
        Thread.sleep(1000);
        groupChatPage.clickSendMessageButton();
    }

    @Then("user see the result text")
    public void userSeeTheResultText() {
        groupChatPage.VerifyTextGroupChatDisplay();
    }


    ////////////// (Positive) Send a image in Group Chat //////////////
    @And("user click Attach icon")
    public void userClickAttachIcon() throws InterruptedException {
        groupChatPage.clickMessageField();
        Thread.sleep(1000);
        groupChatPage.clickAttachButton();
    }

    @And("user click image from gallery")
    public void userClickImageFromGallery() {
        groupChatPage.clickImagefromGalleryButton();
    }

    @And("user click image file and select")
    public void userClickImageFile() {
        groupChatPage.clickImage();
    }

    @Then("user can see the image in chat")
    public void userCanSeeTheImageInChat() throws InterruptedException {
        Thread.sleep(1500);
        groupChatPage.VerifyImageGroupChatDisplay();
    }

    ////////////// (Positive) Send a PDF file in Group Chat //////////////

    @And("user click document and image video")
    public void userClickDocumentAndImageVideo() {
        groupChatPage.clickDocuVidButton();
    }

    @And("user click pdf file and select")
    public void userClickPdfFileAndSelect() throws InterruptedException {
        groupChatPage.ClickclickPDF();
        Thread.sleep(500);
        groupChatPage.clickSelectButtonGC();
    }

    @Then("user can see the pdf file in chat")
    public void userCanSeeThePdfFileInChat() throws InterruptedException {
        Thread.sleep(2000);
        groupChatPage.VerifyPDFGroupChatDisplay();
    }

    ////////////// (Positive) Send a Video in Group Chat //////////////

    @And("user click video and select")
    public void userClickVideoAndSelect() throws InterruptedException {
        groupChatPage.ClickclickVideo();
        Thread.sleep(500);
        groupChatPage.clickSelectButtonGC();
    }

    @Then("user can see the video in chat")
    public void userCanSeeTheVideoInChat() throws InterruptedException {
        Thread.sleep(1000);
        groupChatPage.VerifyVideoGroupChatDisplay();
    }

    ////////////// (Positive) All Member Mention //////////////
    @And("user click message field")
    public void userClickMessageField() throws InterruptedException {
        groupChatPage.clickMessageField();
        Thread.sleep(1000);
    }

    @And("user click @ button")
    public void userClickButton() throws InterruptedException {
        Thread.sleep(1000);
        groupChatPage.clickMentionButton();
    }

    @And("user click mention all button")
    public void userClickMentionAllButton() {
        groupChatPage.clickAllmentionButton();
    }

    @And("user click send button")
    public void userClickSendButton() {
        groupChatPage.clickSendMessageButton();
    }

    @Then("user can see all member mentioned is group chat")
    public void userCanSeeAllMemberMentionedIsGroupChat() throws InterruptedException {
        Thread.sleep(500);
        groupChatPage.VerifyMentionGroupChatDisplay();
    }

    ////////////// (Positive) Delete text chat in Group chat //////////////

    @And("user select text that want to delete")
    public void userSelectTextThatWantToDelete() throws InterruptedException {
        Thread.sleep(500);
        groupChatPage.ClickClickTextDeleteGC();
    }

    @And("user click delete and ok in group chat")
    public void userClickDeleteAndOkInGroupChat() throws InterruptedException {
        Thread.sleep(500);
        groupChatPage.ClickDeleteGC();
        Thread.sleep(500);
        groupChatPage.ClickOKDeleteGCButton();
    }

    @Then("user can see message Delete group chat message success")
    public void userCanSeeMessageDeleteGroupChatMessageSuccess() throws InterruptedException {
        Thread.sleep(1000);
        groupChatPage.VerifiyDeleteGCMessage();
    }

    ////////////// (Negative) Cannot see send button if blank input in message field //////////////

    @Then("user cannot see the send button")
    public void userCannotSeeTheSendButton() throws InterruptedException {
        groupChatPage.clickMessageField();
        Thread.sleep(500);
        groupChatPage.VerifyMessageField();
    }

    ////////////// (Negative) Cannot see delete button in deleted message //////////////

    @And("user click deleted message")
    public void userClickDeletedMessage() {
        groupChatPage.ClickDeletedMessageGC();
    }

    @Then("user cannot see delete button in Group Chat menu")
    public void userCannotSeeDeleteButtonInGroupChatMenu() {
        groupChatPage.VerifyCantSeeDeleteButton();
    }

    ////////////// (Negative) Cannot see mention button in Group Chat //////////////

    @Then("user cannot see mention button in Group Chat")
    public void userCannotSeeMentionButtonInGroupChat() {
        groupChatPage.VerifyMessageField();
    }
}
