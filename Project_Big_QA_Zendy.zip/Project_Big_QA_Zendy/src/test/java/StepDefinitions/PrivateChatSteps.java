package StepDefinitions;

import PageObject.HomePage;
import PageObject.InboxPage;
import Runner.Hooks;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.cucumber.java.BeforeStep;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class PrivateChatSteps {
    public static AndroidDriver<AndroidElement> driver;
    HomePage homePage;
    InboxPage inboxPage;

    public PrivateChatSteps() {
        super();
        this.driver = Hooks.driver;
    }

    @BeforeStep
    public void beforeSetup() {
        inboxPage = new InboxPage(driver);
        homePage = new HomePage(driver);

    }
    @Given("user already at Staging Cicle app and click Menu")
    public void userAlreadyAtStagingCicleAppAndClickMenu() {
        homePage.ClickmenuButton();
    }

    @When("user click inbox")
    public void userClickInbox() {
        homePage.ClickinboxButton();
    }

    @And("user select the member")
    public void userClickSelectedMember() {
        inboxPage.ClickAddMemberButton();
    }


    ////////////// (Positive) Send text via Inbox //////////////

    @And("user send text {string} and send it")
    public void userSendTextAndSendIt(String str) throws InterruptedException {
        inboxPage.ClickinboxMessageField();
        Thread.sleep(500);
        inboxPage.inputInboxMessageField("Hai");
        Thread.sleep(500);
        inboxPage.clickSendInboxMessageButton();
    }

    @Then("user can see text already send it")
    public void userCanSeeTextAlreadySendIt() {
        inboxPage.VerifyTextPrivateChatDisplay();
    }


    ////////////// (Positive) Mention member in Private Chat //////////////

    @And("user select mention button")
    public void userSelectMentionButton() throws InterruptedException {
        inboxPage.ClickinboxMessageField();
        Thread.sleep(1000);
        inboxPage.clickMentionButtonPC();
        Thread.sleep(500);
    }

    @And("user select member name and send it")
    public void userSelectMemberNameAndSendIt() throws InterruptedException {
        inboxPage.clickMemberName();
        Thread.sleep(500);
        inboxPage.clickSendInboxMessageButton();
    }

    @Then("user can see member mentioned in private chat")
    public void userCanSeeMemberMentionedInPrivateChat() {
        inboxPage.VerifyMentionPrivateChatDisplay();
    }

    ////////////// (Positive) Delete message in Private Chat //////////////

    @And("user select text that want to delete in Private Chat")
    public void userSelectTextThatWantToDeleteInPrivateChat() {
        inboxPage.ClickTextDeletePC();
    }

    @And("user click delete and ok in Private Chat")
    public void userClickDeleteAndOkInPrivateChat() {
        inboxPage.ClickDeletePC();
        inboxPage.ClickOKDeletePCButton();
    }

    @Then("user can see message Delete chat message success")
    public void userCanSeeMessageDeleteChatMessageSuccess() {
        inboxPage.VerifyDeletePCMessage();
    }

    ////////////// (Negative) Cannot see send button if blank input in message field in Private Chat //////////////

    @And("user click message field in Private chat")
    public void userClickMessageFieldInPrivateChat() {
        inboxPage.ClickinboxMessageField();
    }

    @Then("user cannot see the send button in Private Chat")
    public void userCannotSeeTheSendButtonInPrivateChat() {
        inboxPage.VerifyinboxMessageField();
    }

    ////////////// (Negative) Cannot see delete button in deleted message in Private Chat //////////////

    @And("user click deleted message in Private Chat")
    public void userClickDeletedMessageInPrivateChat() {
        inboxPage.ClickDeletedMessagePC();
    }

    @Then("user cannot see delete button in Private Chat menu")
    public void userCannotSeeDeleteButtonInPrivateChatMenu() {
        inboxPage.VerifyCantSeeDeleteButton();
    }

    ////////////// (Negative) Cannot see mention button in Private Chat //////////////

    @Then("user cannot see mention button in Private Chat")
    public void userCannotSeeMentionButtonInPrivateChat() {
        inboxPage.VerifyinboxMessageField();
    }

}
