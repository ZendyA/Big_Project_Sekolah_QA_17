package StepDefinitions;

import PageObject.CheckInsPage;
import PageObject.GroupChatPage;
import PageObject.HomePage;
import PageObject.TestingTeamPage;
import Runner.Hooks;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.cucumber.java.BeforeStep;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CheckInsStep {
    public static AndroidDriver<AndroidElement> driver;

    CheckInsPage checkInsPage;
    HomePage homePage;
    TestingTeamPage testingTeamPage;

    public CheckInsStep() {
        super();
        this.driver = Hooks.driver;
    }

    @BeforeStep
    public void beforeSetup() {
        checkInsPage = new CheckInsPage(driver);
        homePage = new HomePage(driver);
        testingTeamPage = new TestingTeamPage(driver);

    }

    @When("User click Check-Ins in Testing Team")
    public void userClickCheckInsInTestingTeam() {
        testingTeamPage.ClickCheckIns();
    }
    ////////////// (Positive) Create Check-Ins //////////////

    @And("User click Add button in Check-Ins page")
    public void userClickAddButtonInCheckInsPage() {
        checkInsPage.ClickAddCheckInsButton();
    }

    @And("User input text {string} in ask question field")
    public void userInputTextInAskQuestionField(String str) throws InterruptedException {
        checkInsPage.ClickQuestionField();
        Thread.sleep(1000);
        checkInsPage.InputQuestionField("Testing");
        Thread.sleep(500);
    }

    @And("User selects the day to submit the question")
    public void userSelectsTheDayToSubmitTheQuestion() {
        checkInsPage.ClickTuesday();
    }

    @And("User set the time in set time button")
    public void userSetTheTimeInSetTimeButton() throws InterruptedException {
        checkInsPage.ClickSetTimeButton();
        Thread.sleep(500);
        checkInsPage.ClickOkSelectTimeButton();
    }

    @And("User click start collecting answers! button")
    public void userClickStartCollectingAnswersButton() {
        checkInsPage.ClickCollectingAnswerButton();
    }

    @Then("User can see message the question is successfully created")
    public void userCanSeeMessageTheQuestionIsSuccessfullyCreated() throws InterruptedException {
        Thread.sleep(1000);
        checkInsPage.MessageCreateQuestSuccess();
        Thread.sleep(1000);
    }

    ////////////// (Negative) Blank all data or question data only in check-ins //////////////

    @Then("User can see error message the question is unsuccessfully created")
    public void userCanSeeErrorMessageTheQuestionIsUnsuccessfullyCreated() {
        checkInsPage.MessageQuestionNegative();
    }

    ////////////// (Negative) Blank day table data in check-ins //////////////

    @Then("User can see error message how often the question is asked to be filled in and the Check-ins unsuccessfully created")
    public void userCanSeeErrorMessageHowOftenTheQuestionIsAskedToBeFilledInAndTheCheckInsUnsuccessfullyCreated() {
        checkInsPage.MessageDayTableNegative();
    }

    ////////////// (Negative) Blank set time data in check-ins //////////////

    @And("User click blank area")
    public void userClickBlankArea() throws InterruptedException {
        Thread.sleep(500);
        checkInsPage.ClickBlankTap();
    }

    @Then("User can see error message time must be filled and the Check-ins unsuccessfully created")
    public void userCanSeeErrorMessageTimeMustBeFilledAndTheCheckInsUnsuccessfullyCreated() throws InterruptedException {
        checkInsPage.MessageSetTimeNegative();
    }

    ////////////// (Negative) cannot create comment with blank data in Question //////////////

    @And("User click Question that already created")
    public void userClickQuestionThatAlreadyCreated() throws InterruptedException {
        checkInsPage.ClickQuestionCheckIns();
        Thread.sleep(1000);
    }

    @And("User click add new comment field at question")
    public void userClickAddNewCommentFieldAtQuestion() {
        checkInsPage.ClickNewCommentCheckIns();
    }

    @And("User click submit in comment menu")
    public void userClickSubmitInCommentMenu() throws InterruptedException {
        Thread.sleep(1000);
        checkInsPage.ClickSubmitQuestionButton();
        Thread.sleep(500);
    }

    @Then("User can see error message comments can't be empty")
    public void userCanSeeErrorMessageCommentsCanTBeEmpty() {
        checkInsPage.MessageErrorCommentQuestion();
    }

    ////////////// (Positive) Create comment with valid data in Question //////////////

    @And("User click add new comment field at question and input text {string}")
    public void userClickAddNewCommentFieldAtQuestionAndInputText(String arg0) throws InterruptedException {
        checkInsPage.ClickNewCommentCheckIns();
        Thread.sleep(500);
        checkInsPage.ClickTypeCommentCheckIns();
        Thread.sleep(500);
        checkInsPage.InputTypeCommentCheckIns("Testing comment");
    }

    @Then("User can see comment already created")
    public void userCanSeeCommentAlreadyCreated() {
        checkInsPage.VerifyTextCommentCheckIns();
    }
}
