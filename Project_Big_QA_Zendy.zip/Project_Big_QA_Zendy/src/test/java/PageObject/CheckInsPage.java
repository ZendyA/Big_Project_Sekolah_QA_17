package PageObject;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;

public class CheckInsPage {
    public CheckInsPage(AndroidDriver<AndroidElement> driver) {
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }
    ////////////// (Positive) Create Check-Ins //////////////

    @AndroidFindBy(xpath = "//android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.widget.Button")
    private AndroidElement AddCheckInsButton;
    public void ClickAddCheckInsButton(){
        AddCheckInsButton.click();
    }

    @AndroidFindBy(xpath = "//android.widget.EditText[@text=\"type question here...\"]")
    private AndroidElement QuestionField;
    public void ClickQuestionField(){
        QuestionField.click();
    }

    public void InputQuestionField(String keyword){
        QuestionField.sendKeys(keyword);
    }

    @AndroidFindBy(accessibility = "Tue")
    private AndroidElement TuesDay;
    public void ClickTuesday(){
        TuesDay.click();
    }

    @AndroidFindBy(accessibility = "set time")
    private AndroidElement SetTimeButton;
    public void ClickSetTimeButton(){
        SetTimeButton.click();
    }
    @AndroidFindBy(accessibility = "OK")
    private AndroidElement OkSelectTimeButton;
    public void ClickOkSelectTimeButton(){
        OkSelectTimeButton.click();
    }
    @AndroidFindBy(accessibility = "Start collecting answer!")
    private AndroidElement CollectingAnswerButton;
    public void ClickCollectingAnswerButton(){
        CollectingAnswerButton.click();
    }
    @AndroidFindBy(accessibility = "Create question successful")
    private AndroidElement CreateQuestSuccess;
    public void MessageCreateQuestSuccess(){
        CreateQuestSuccess.isDisplayed();
    }
    ////////////// (Negative) Blank all data or question data only in check-ins //////////////
    @AndroidFindBy(accessibility = "question must be filled")
    private AndroidElement QuestionNegative;
    public void MessageQuestionNegative(){
        QuestionNegative.isDisplayed();
    }

    ////////////// (Negative) Blank day table data in check-ins //////////////
    @AndroidFindBy(accessibility = "how often the question is asked to be filled in")
    private AndroidElement DayTableNegative;
    public void MessageDayTableNegative(){
        DayTableNegative.isDisplayed();
    }

    ////////////// (Negative) Blank set time data in check-ins //////////////
    @AndroidFindBy(accessibility = "time must be filled")
    private AndroidElement SetTimeNegative;
    public void MessageSetTimeNegative(){
        SetTimeNegative.isDisplayed();
    }
    @AndroidFindBy(xpath = "//android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View/android.widget.ScrollView")
    private AndroidElement BlankTap;
    public void ClickBlankTap(){
        BlankTap.click();
    }

    ////////////// (Negative) cannot create comment with blank data in Question //////////////
    @AndroidFindBy(xpath = "//android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.view.View")
    private AndroidElement QuestionCheckIns;
    public void ClickQuestionCheckIns(){
        QuestionCheckIns.click();
    }
    @AndroidFindBy(accessibility = "Add new comment...")
    private AndroidElement NewCommentCheckIns;
    public void ClickNewCommentCheckIns(){
        NewCommentCheckIns.click();
    }

    @AndroidFindBy(accessibility = "submit")
    private AndroidElement SubmitQuestionButton;
    public void ClickSubmitQuestionButton(){
        SubmitQuestionButton.click();
    }
    @AndroidFindBy(accessibility = "comments can't be empty")
    private AndroidElement ErrorCommentQuestion;
    public void MessageErrorCommentQuestion(){
        ErrorCommentQuestion.isDisplayed();
    }

    ////////////// (Positive) Create comment with valid data in Question //////////////

    @AndroidFindBy(xpath = "//android.view.View[contains(@content-desc, 'Testing comment')]")
    private AndroidElement TextCommentCheckIns;
    public void VerifyTextCommentCheckIns(){
        TextCommentCheckIns.isDisplayed();
    }

    @AndroidFindBy(xpath = "//android.view.View[3]/android.view.ViewGroup/android.webkit.WebView/android.webkit.WebView/android.view.View/android.view.View[2]/android.widget.EditText")
    private AndroidElement TypeCommentCheckIns;
    public void ClickTypeCommentCheckIns(){
        TypeCommentCheckIns.click();
    }
    public void InputTypeCommentCheckIns(String keyword) {
        TypeCommentCheckIns.sendKeys(keyword);
    }
}
