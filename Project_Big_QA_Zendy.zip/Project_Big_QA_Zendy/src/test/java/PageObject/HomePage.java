package PageObject;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;

public class HomePage {
    public HomePage(AndroidDriver<AndroidElement> driver) {
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }
    @AndroidFindBy(accessibility = "Testing\n" +
            "Testing")
    private AndroidElement TestingTeam;
    public void ClickTestingTeam(){
        TestingTeam.click();
    }
    @AndroidFindBy(accessibility = "Menu\n" +
            "Tab 4 of 4")
    private AndroidElement MenuButton;
    public void ClickmenuButton() {
        MenuButton.click();
    }
    @AndroidFindBy(accessibility = "Inbox")
    private AndroidElement InboxButton;
    public void ClickinboxButton() {
        InboxButton.click();
    }

}
