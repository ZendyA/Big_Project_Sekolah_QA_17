package PageObject;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;

public class InboxPage {
    public InboxPage(AndroidDriver<AndroidElement> driver) {
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }

    ////////////// (Positive) Send text via Inbox //////////////
    @AndroidFindBy(xpath = "//android.widget.ImageView[contains(@content-desc, 'Muh Buni')]")
    private AndroidElement AddMemberButton;
    public void ClickAddMemberButton() {
        AddMemberButton.click();
    }

    @AndroidFindBy(xpath = "//android.widget.EditText[@text=\"type message...\"]")
    private AndroidElement InboxmessageField;
    public void ClickinboxMessageField(){
        InboxmessageField.click();
    }
    public void inputInboxMessageField(String keyword){
        InboxmessageField.sendKeys(keyword);
    }

    public void VerifyinboxMessageField(){
        InboxmessageField.isDisplayed();
    }
    @AndroidFindBy(xpath = "//android.widget.Button[@index=\"5\"]")
    private AndroidElement sendInboxMessageButton;
    public void clickSendInboxMessageButton(){
        sendInboxMessageButton.click();
    }
    @AndroidFindBy(xpath = "//android.view.View[contains(@content-desc, 'Hai')]")
    private AndroidElement TextPrivateChatDisplay;
    public void VerifyTextPrivateChatDisplay(){
        TextPrivateChatDisplay.isDisplayed();
    }

    ////////////// (Positive) Mention member in Private Chat //////////////
    @AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View[3]")
    private AndroidElement MentionButtonPC;
    public void clickMentionButtonPC(){
        MentionButtonPC.click();
    }
    @AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc=\"Muh Buni\"]")
    private AndroidElement MemberName;
    public void clickMemberName(){
        MemberName.click();
    }
    @AndroidFindBy(xpath = "//android.widget.ImageView[@content-desc=\"Muh Buni\"]")
    private AndroidElement MentionPrivateChatDisplay;
    public void VerifyMentionPrivateChatDisplay(){
        MentionPrivateChatDisplay.isDisplayed();
    }


    ////////////// (Positive) Delete text chat in Private chat //////////////
    @AndroidFindBy(xpath = "(//android.view.View)[contains(@content-desc, 'Hai')][last()]")
    private AndroidElement ClickTextDeletePC;
    public void ClickTextDeletePC(){
        ClickTextDeletePC.click();
    }

    @AndroidFindBy(accessibility = "Delete")
    private AndroidElement DeletePC;
    public void ClickDeletePC(){
        DeletePC.click();
    }

    @AndroidFindBy(accessibility = "Ok")
    private AndroidElement OKDeletePCButton;
    public void ClickOKDeletePCButton(){
        OKDeletePCButton.click();
    }

    @AndroidFindBy(accessibility = "Delete chat message success")
    private AndroidElement DeletePCMessage;
    public void VerifyDeletePCMessage(){
        DeletePCMessage.isDisplayed();
    }

    ////////////// (Negative) Cannot see delete button in deleted message in Private Chat //////////////

    @AndroidFindBy(xpath = "(//android.view.View)[contains(@content-desc, 'deleted')][last()]")
    private AndroidElement DeletedMessagePC;
    public void ClickDeletedMessagePC(){
        DeletedMessagePC.click();
    }

    @AndroidFindBy(accessibility = "Copy")
    private AndroidElement CopyButtonGC;
    @AndroidFindBy(accessibility = "Select")
    private AndroidElement SelectButtonMessageGC;
    public void VerifyCantSeeDeleteButton(){
        CopyButtonGC.isDisplayed();
        SelectButtonMessageGC.isDisplayed();

    }
}
