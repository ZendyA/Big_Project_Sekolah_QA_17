package PageObject;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

public class GroupChatPage {
    public GroupChatPage(AndroidDriver<AndroidElement> driver) {
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }

    ////////////// (Positive) Input text in Group Chat //////////////
    @AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.widget.EditText")
    private AndroidElement messageField;
    public void clickMessageField(){
        messageField.click();
    }
    public void inputMessageField(String keyword){
        messageField.sendKeys(keyword);
    }
    public void VerifyMessageField() {
        messageField.isDisplayed();
    }

    @AndroidFindBy(xpath = "//android.widget.Button[@index=\"6\"]")
    private AndroidElement sendMessageButton;
    public void clickSendMessageButton(){
        sendMessageButton.click();
    }
    @AndroidFindBy(xpath = "//android.view.View[contains(@content-desc, 'Test')]")
    private AndroidElement TextGroupChatDisplay;
    public void VerifyTextGroupChatDisplay(){
        TextGroupChatDisplay.isDisplayed();
    }

    ////////////// (Positive) Mention member feature //////////////
    @AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View[4]")
    private AndroidElement MentionButton;
    public void clickMentionButton(){
        MentionButton.click();
    }
    @AndroidFindBy(accessibility = "mention all")
    private AndroidElement AllmentionButton;
    public void clickAllmentionButton(){
        AllmentionButton.click();
    }

    @AndroidFindBy(xpath = "//android.view.View[contains(@content-desc, '￼')]")
    private AndroidElement MentionGroupChatDisplay;
    public void VerifyMentionGroupChatDisplay(){
        MentionGroupChatDisplay.isDisplayed();
    }

    ////////////// (Positive) Attach image feature //////////////
    @AndroidFindBy(xpath = "/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View[5]")
    private AndroidElement AttachButton;
    public void clickAttachButton(){
        AttachButton.click();
    }
    @AndroidFindBy(accessibility = "Image from Gallery")
    private AndroidElement ImagefromGalleryButton;
    public void clickImagefromGalleryButton(){
        ImagefromGalleryButton.click();
    }
    @AndroidFindBy(id = "com.google.android.documentsui:id/icon_thumb")
    private AndroidElement clickImage;
    public void clickImage(){
        clickImage.click();
    }
    @AndroidFindBy(xpath = "//android.widget.ImageView[contains(@content-desc, 'AM')] | //android.widget.ImageView[contains(@content-desc, 'PM')]")
    private AndroidElement ImageGroupChatDisplay;
    public void VerifyImageGroupChatDisplay(){
        ImageGroupChatDisplay.isDisplayed();
    }

    ////////////// (Positive) Send a PDF file in Group Chat //////////////

    @AndroidFindBy(accessibility = "Document & Video")
    private AndroidElement DocuVidButton;
    public void clickDocuVidButton(){
        DocuVidButton.click();
    }

    @AndroidFindBy(id = "com.google.android.documentsui:id/icon_mime")
    private AndroidElement clickPDF;
    public void ClickclickPDF(){
        clickPDF.click();
    }

    @AndroidFindBy(id = "com.google.android.documentsui:id/action_menu_select")
    private AndroidElement SelectButtonGC;
    public void clickSelectButtonGC(){
        SelectButtonGC.click();
    }

    @AndroidFindBy(xpath = "//android.widget.ImageView[contains(@content-desc, 'pdf')]")
    private AndroidElement PDFGroupChatDisplay;
    public void VerifyPDFGroupChatDisplay(){
        PDFGroupChatDisplay.isDisplayed();
    }

    ////////////// (Positive) Send a Video in Group Chat //////////////

    @AndroidFindBy(xpath = "//android.widget.LinearLayout[1]/android.widget.LinearLayout/android.widget.FrameLayout[1]/androidx.cardview.widget.CardView/android.widget.ImageView")
    private AndroidElement clickVideo;
    public void ClickclickVideo(){
        clickVideo.click();
    }

    @AndroidFindBy(xpath = "//android.widget.ImageView[contains(@content-desc, 'mp4')]")
    private AndroidElement VideoGroupChatDisplay;
    public void VerifyVideoGroupChatDisplay(){
        VideoGroupChatDisplay.isDisplayed();
    }

    ////////////// (Positive) Delete text chat in Group chat //////////////
    @AndroidFindBy(xpath = "(//android.view.View)[contains(@content-desc, 'Test')][last()]")
    private AndroidElement ClickTextDeleteGC;
    public void ClickClickTextDeleteGC(){
        ClickTextDeleteGC.click();
    }

    @AndroidFindBy(accessibility = "Delete")
    private AndroidElement DeleteGC;
    public void ClickDeleteGC(){
        DeleteGC.click();
    }

    @AndroidFindBy(accessibility = "Ok")
    private AndroidElement OKDeleteGCButton;
    public void ClickOKDeleteGCButton(){
        OKDeleteGCButton.click();
    }

    @AndroidFindBy(accessibility = "Delete group chat message success")
    private AndroidElement DeleteGCMessage;
    public void VerifiyDeleteGCMessage(){
        DeleteGCMessage.isDisplayed();
    }

    ////////////// (Negative) Cannot see delete button in deleted message //////////////

    @AndroidFindBy(xpath = "(//android.view.View)[contains(@content-desc, 'deleted')][last()]")
    private AndroidElement DeletedMessageGC;
    public void ClickDeletedMessageGC(){
        DeletedMessageGC.click();
    }

    @AndroidFindBy(accessibility = "Copy")
    private AndroidElement CopyButtonGC;
    @AndroidFindBy(accessibility = "Select")
    private AndroidElement SelectButtonMessageGC;
    public void VerifyCantSeeDeleteButton(){
        CopyButtonGC.isDisplayed();
        SelectButtonMessageGC.isDisplayed();

    }
}
