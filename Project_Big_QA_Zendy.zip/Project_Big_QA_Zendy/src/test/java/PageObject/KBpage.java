package PageObject;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import org.openqa.selenium.support.PageFactory;

public class KBpage {
    public KBpage(AndroidDriver<AndroidElement> driver) {
        PageFactory.initElements(new AppiumFieldDecorator(driver), this);
    }
    ////////////// (Positive) Add Board List //////////////
    @AndroidFindBy(xpath = "//android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.widget.Button")
    private AndroidElement AddBoardListButton;
    public void ClickAddBoardListButton(){
        AddBoardListButton.click();
    }
    @AndroidFindBy(xpath = "//android.widget.EditText[@text=\"Add new list...\"]")
    private AndroidElement BoardListNameField;
    public void InputBoardListNameField(String keyword){
        BoardListNameField.sendKeys(keyword);
    }
    @AndroidFindBy(accessibility = "Submit")
    private AndroidElement BoardListSubmitButton;
    public void ClickBoardListSubmitButton(){
        BoardListSubmitButton.click();
    }

    ////////////// (Positive) Add Card //////////////
    @AndroidFindBy(accessibility = "Add new card")
    private AndroidElement AddNewCardButton;
    public void ClickAddNewCardButton(){
        AddNewCardButton.click();
    }
    public void VerifyAddNewCardButton(){
        AddNewCardButton.isDisplayed();
    }
    @AndroidFindBy(xpath = "//android.widget.EditText[@text=\"Your card name\"]")
    private AndroidElement CardNameField;
    public void InputCardNameField(String keyword){
        CardNameField.sendKeys(keyword);
    }
    @AndroidFindBy(xpath = "//android.view.View[@content-desc=\"Private Card\"]/android.widget.EditText/android.view.View")
    private AndroidElement SaveCardButton;
    public void ClickSaveCardButton(){
        SaveCardButton.click();
    }

    ////////////// (Positive) Comment in Card //////////////
    @AndroidFindBy(accessibility = "Testing card\n" +
            "1\n" +
            "Show menu")
    private AndroidElement TestingCardButton1;
    public void ClickTestingCardButton1(){
        TestingCardButton1.click();
    }
    @AndroidFindBy(accessibility = "Add new comment...")
    private AndroidElement NewCommentCardField;
    public void ClickNewCommentCardField(){
        NewCommentCardField.click();
    }
    @AndroidFindBy(xpath = "//android.webkit.WebView/android.view.View/android.view.View[2]/android.widget.EditText")
    private AndroidElement InputCommentCardField;
    public void ClickInputCommentCardField(String keyword) {
        InputCommentCardField.sendKeys(keyword);
    }
    @AndroidFindBy(accessibility = "submit")
    private AndroidElement SubmitCommentCardButton;
    public void ClickSubmitCommentCardButton(){
        SubmitCommentCardButton.click();
    }

    ////////////// (Positive) Attach file in Card //////////////

    @AndroidFindBy(accessibility = "Testing card\n" +
            "Show menu")
    private AndroidElement TestingCardButton;
    public void ClickTestingCardButton(){
        TestingCardButton.click();
    }
    @AndroidFindBy(accessibility = "Attach file")
    private AndroidElement AttachFileCard;
    public void ClickAttachFileCard(){
        AttachFileCard.click();
    }
    @AndroidFindBy(id = "com.google.android.documentsui:id/icon_thumb")
    private AndroidElement SelectFileAttachCard;
    public void ClickSelectFileAttachCard() {
        SelectFileAttachCard.click();
    }
    @AndroidFindBy(id = "com.google.android.documentsui:id/action_menu_select")
    private AndroidElement SelectFileButton;
    public void ClickSelectFileButton() {
        SelectFileButton.click();
    }
    @AndroidFindBy(accessibility = "Upload attachments is success")
    private AndroidElement UploadAttachSuccess;
    public void MessageUploadAttachSuccess(){
        UploadAttachSuccess.isDisplayed();
    }

    ////////////// (Positive) Archive board //////////////
    @AndroidFindBy(xpath = "//android.widget.FrameLayout/android.view.View/android.view.View/android.view.View/android.view.View[2]/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View[2]")
    private AndroidElement MenuBoardButton;
    public void ClickMenuBoardButton() {
        MenuBoardButton.click();
    }
    @AndroidFindBy(accessibility = "Archive this list")
    private AndroidElement ArchiveBoardList;
    public void ClickArchiveBoardList(){
        ArchiveBoardList.click();
    }
    @AndroidFindBy(accessibility = "List has been moved to archive")
    private AndroidElement MessageArchiveBoardList;
    public void NotifMessageArchiveBoardList() {
        MessageArchiveBoardList.isDisplayed();
    }

    ////////////// (Negative) cannot create Board List with blank data //////////////

    @AndroidFindBy(accessibility = "Add Board List")
    private AndroidElement TitleAddBoardList;
    public void VerifyTitleAddBoardList() {
        TitleAddBoardList.isDisplayed();
    }

    ////////////// (Positive) Set card to private //////////////

    @AndroidFindBy(xpath = "(//android.widget.Button[@content-desc=\"Show menu\"])[1]")
    private AndroidElement ShowMenuCIButton;
    public void ClickShowMenuCIButton(){
        ShowMenuCIButton.click();
    }

    @AndroidFindBy(accessibility = "Set card to private")
    private AndroidElement SetCardPrivateCI;
    public void ClickSetCardPrivateCI(){
        SetCardPrivateCI.click();
    }

    @AndroidFindBy(accessibility = "Update card is success")
    private AndroidElement MessageUpdateCard;
    public void VerifyMessageUpdateCard() {
        MessageUpdateCard.isDisplayed();
    }
}
