package Runner;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

public class Hooks {
    public static AndroidDriver<AndroidElement> driver;

    @Before
    public static void setUp() throws MalformedURLException {
        DesiredCapabilities capab = new DesiredCapabilities();

        capab.setCapability("platformName", "Android");
        capab.setCapability("platformVersion", "12");
        capab.setCapability("deviceName", "emulator-5554");

        capab.setCapability("appPackage", "staging.cicle");
        capab.setCapability("appActivity", "staging.cicle.MainActivity");
        capab.setCapability("noReset", "true");

        URL url = new URL("http://127.0.0.1:4723/wd/hub");
        driver = new AndroidDriver<>(url, capab);

        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    }

    //    @After(order = 0)
    @After
    public void tearDown(){
        driver.closeApp();
    }

//    @After(order = 1)
//    public void takeScraenshotOnFailure(Scenario scenario) {
//
//        if (scenario.isFailed()) {
//            TakesScreenshot ts = (TakesScreenshot) driver;
//
//            byte[] src = ts.getScreenshotAs(OutputType.BYTES);
//            scenario.attach(src, "image/png", "screenshot");
//        }
//    }
}
